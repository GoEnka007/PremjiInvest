from repository.vector_db import VectorDB
from service.llm_service import get_chat_response


class ConversationService:
    def __init__(self):
        self.vdb = VectorDB()

    async def chat(self, query: str):
        prompt = await self.vdb.get_prompt(query)
        context = await self.vdb.get_context(prompt)
        llm_response = await get_chat_response(prompt, context=context)
        return llm_response
