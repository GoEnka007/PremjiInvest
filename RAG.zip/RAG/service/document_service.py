from fastapi import UploadFile

from repository.vector_db import VectorDB
from service.llm_service import generate_embeddings

vdb = VectorDB()


async def process_document_for_rag(file: UploadFile):
    # TODO: Implement this method to process a document for RAG
    chunks = await vdb.generate_text_chunks(file)
    chunks_with_embeddings = await generate_embeddings(chunks)
    return await vdb.save_chunks_to_db(chunks_with_embeddings)



def upload_document(file: UploadFile):
    """
    Placeholder implementation to upload the document.
    This function should handle the actual uploading of the document to the desired storage location.
    """
    # For example, you could save the file to the specified upload folder
    with open(os.path.join(UPLOAD_FOLDER, file.filename), "wb") as f:
        f.write(file.file.read())           #confirm this code

openai.api_key = 'your_openai_api_key_here'

def process_document_for_rag(file: UploadFile):
    """
    Placeholder implementation to process the document for RAG.
    This function uses OpenAI to process the document for RAG (Retrieval-Augmented Generation).
    """
    try:
        # Save the uploaded file temporarily
        with NamedTemporaryFile(delete=False) as temp_file:
            temp_file.write(file.file.read())
            temp_file_path = temp_file.name
        
        # Read the contents of the uploaded file
        with open(temp_file_path, 'r', encoding='utf-8') as f:
            document_text = f.read()
        
        # Process the document using OpenAI for RAG
        response = openai.Completion.create(
            engine="text-davinci-003",
            prompt=document_text,
            temperature=0.7,
            max_tokens=150
        )
        
        # Extract the generated text from the response
        generated_text = response.choices[0].text.strip()
        
        # Return the generated text as the processed result
        return {"processed_text": generated_text}  #why are we printing the text?
    
    except Exception as e:
        # Handle exceptions, if any
        return {"error": str(e)}
    finally:
        # Remove the temporary file
        if temp_file_path:
            os.remove(temp_file_path)
