import os
import fitz
from fastapi import UploadFile
from langchain.schema.document import Document
from langchain_community.vectorstores import FAISS
from service.llm_service import embeddings
import PyPDF2
import io
from typing import List

class VectorDB:
    def __init__(self):
        self.embeddings = OpenAIEmbeddings(api_key="your_openai_api_key_here")
        self.db = {}

    async def generate_text_chunks(self, file: UploadFile):
        try:
            text_chunks = []
            with io.BytesIO(await file.read()) as pdf_stream:
                pdf_reader = PyPDF2.PdfFileReader(pdf_stream)
                for page_num in range(pdf_reader.numPages):
                    page = pdf_reader.getPage(page_num)
                    text_chunks.append(page.extractText())
            return text_chunks
        except Exception as e:
            # Handle exceptions, if any
            print("Error:", e)
            return []
        pass

    async def encode_and_store(self, chunks):
        """Encodes data points and stores their vectors in memory."""
        # TODO: Implement a method to get vector embeddings for chunks and store data in a database
        try:
            encoded_vectors = await self.embeddings.create(chunks)
            for chunk, vector in zip(chunks, encoded_vectors):
                self.db[chunk] = vector
        except Exception as e:
            # Handle exceptions, if any
            print("Error:", e)
        pass

    async def calculate_query_vector(self, query: str) -> List[float]:
        """
        Calculates the vector representation of the query.

        Args:
            query (str): The query string.

        Returns:
            List[float]: The vector representation of the query.
        """
        try:
            query_embedding = await self.embeddings.create(query)
            query_vector = query_embedding[0]['embedding']
            return query_vector
        except Exception as e:
            # Handle exceptions, if any
            print("Error:", e)
            return []
        
    async def find_matching_vectors(self, query: str):
        """
        Finds matching vectors based on a query vector.

        Args:
            query (str): The query string.

        Returns:
            List[Dict[str, str]]: A list of dictionaries containing matched documents.
        """
        matched_docs = []
        query_vector = await calculate_query_vector(self,query)
        
        # Placeholder logic to find matching vectors based on query vector
        for doc, vector in self.db.items():
            similarity = self.calculate_similarity(query_vector, vector)
            matched_docs.append({"page_content": doc, "similarity": similarity})
        
        # Sort matched docs by similarity
        matched_docs.sort(key=lambda x: x["similarity"], reverse=True)
        
        return matched_docs

    def calculate_similarity(self, vector1: List[float], vector2: List[float]) -> float:
        """
        Calculates the cosine similarity between two vectors.

        Args:
            vector1 (List[float]): The first vector.
            vector2 (List[float]): The second vector.

        Returns:
            float: The cosine similarity score between the two vectors.
        """
        # Calculate cosine similarity
        cosine_sim = dot(vector1, vector2) / (norm(vector1) * norm(vector2))
        return cosine_sim
    async def get_context(self, query: str) -> str:
        """
        Searches for matching vectors based on a query vector.

        Args:
            query (str): The query string.

        Returns:
            str: A string containing matched documents.
        """
        try:
            matched_docs = self.find_matching_vectors(query)
            return '\n\n'.join([doc['page_content'] for doc in matched_docs])
        except Exception as e:
            # Handle exceptions, if any
            print("Error:", e)
            return ''


    async def get_prompt(self, query):
        prompt_template = "Ask a question related to '{query}'"
        prompt = prompt_template.format(query=query)
        return prompt


    def get_refined_query(self, query):
        # TODO: Implement a method to refine the query for better search results (such as removing stopwords, adding synonyms, etc.)

        return query

    async def save_chunks_to_db(self, chunks):
        embeddings = await self.embeddings.create(chunks)
            
        # Store chunks and their embeddings in the database
        for chunk, embedding in zip(chunks, embeddings):
            self.db[chunk] = embedding['embedding']
        pass
