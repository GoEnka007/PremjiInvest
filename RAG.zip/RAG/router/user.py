from fastapi import APIRouter, Body

from repository.vector_db import VectorDB
from service.llm_service import get_chat_response

user_router = APIRouter()


@user_router.post("/login")
async def login():
    """
    User login endpoint
    Returns:

    """
    # TODO: Read the method signature and implement the method
    pass


@user_router.post("/register")
async def register():
    """
    User registration endpoint
    Returns:

    """
    # TODO: Read the method signature and implement the method
    pass


@user_router.post("/logout")
async def logout():
    """
    User logout endpoint
    Returns:

    """
    # TODO: Read the method signature and implement the method
    pass


@user_router.get("/user")
async def get_user_details():
    """
    User get endpoint
    Returns:

    """
    # TODO: Read the method signature and implement the method
    pass


@user_router.post("/user")
async def set_user_details():
    """
    User create/update endpoint
    Returns:

    """
    # TODO: Read the method signature and implement the method
    pass
