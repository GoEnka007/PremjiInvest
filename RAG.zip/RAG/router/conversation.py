from fastapi import APIRouter, Body

from repository.vector_db import VectorDB
from service.conversation_service import ConversationService
from service.llm_service import get_chat_response

conversation_router = APIRouter()
conversation_service = ConversationService()


@conversation_router.post("/chat")
async def chat(query: str = Body(default="Your query...")):
    
    return conversation_service.chat(query)


@conversation_router.post("/new-chat")
async def new_chat():
    """
    This will invalidate the context (currently uploaded documents and chunks) and start a new conversation
    Args:
        query:

    Returns:

    """
    # TODO: Read the method signature and implement the method
    pass
