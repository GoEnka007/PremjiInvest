from typing import List
import faiss
from fastapi import APIRouter, File, UploadFile
from repository.vector_db import VectorDB #import other librarires as required
from service.document_service import upload_document, process_document_for_rag

document_router = APIRouter()


def process_and_store_chunks(chunks):
    embeddings_list = []

    try:
        # Iterate over each chunk
        for chunk in chunks:
            # Call OpenAI's API to generate embeddings for the chunk
            response = openai.Embed.create(
                model="text-davinci-003",
                documents=[chunk]
            )

            # Extract the embedding for the chunk
            embedding = response['embedding']

            # Append the embedding to the list
            embeddings_list.append(embedding)

        # Store the embeddings in the vector database
        # Implement your logic to store embeddings in the vector database
        # Here, we simply print out the embeddings as a placeholder
        for embedding in embeddings_list:
            print("Stored embedding:", embedding)   #why printing?

    except Exception as e:
        # Handle exceptions, if any
        print("Error:", e)

@document_router.post("/process-document")
async def process_document(file: UploadFile):
    if not file:
        raise HTTPException(status_code=400, detail="No file uploaded")
    
    try:
        # Save the uploaded file temporarily
        with NamedTemporaryFile(delete=False, dir=UPLOAD_FOLDER) as temp_file:    #define upload folder
            temp_file.write(await file.read())
            temp_file_path = temp_file.name
        
        # Upload the document
        upload_document(file)
        
        # Process the document in chunks
        with open(temp_file_path, 'r', encoding='utf-8') as f:
            chunks = f.read().split('\n\n')  
        
        # Store the processed chunks in the vector database
        process_and_store_chunks(chunks)
        
        # Process the document for RAG
        result = process_document_for_rag(file)
        
        return JSONResponse(content={"message": "Document processed successfully", "result": result})
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        # Remove the temporary file
        os.remove(temp_file_path)


def get_documents_list() -> List[dict]:
    documents_list = []
    for file_path in Path(DOCUMENTS_DIR).iterdir():
        if file_path.suffix.lower() == ".pdf":
            documents_list.append({"doc_id": str(file_path.stem), "doc_name": file_path.name})
    return documents_list

@app.get("/get-documents")
async def get_documents():
    documents_list = get_documents_list()
    return documents_list

@app.get("/get-document/{doc_id}")
async def get_document(doc_id: str):
    document_path = os.path.join(DOCUMENTS_DIR, f"{doc_id}.pdf")
    if not os.path.exists(document_path):
        raise HTTPException(status_code=404, detail="Document not found")
    return FileResponse(document_path, media_type="application/pdf")
